var APP_DATA = {
  "scenes": [
    {
      "id": "0-gare-maritime",
      "name": "Gare Maritime",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": -2.5138885461576486,
        "pitch": 0.37992893373493075,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": -0.918429031311593,
          "pitch": 0.23956347912299414,
          "rotation": 0,
          "target": "4-porte-principale"
        },
        {
          "yaw": 2.846931282579952,
          "pitch": 0.010533710912119076,
          "rotation": 0,
          "target": "1-digue_principale"
        },
        {
          "yaw": -2.8946206988329557,
          "pitch": 0.000048964888403446594,
          "rotation": 0,
          "target": "2-milieu-digue"
        },
        {
          "yaw": -1.4123861845027985,
          "pitch": 0.0728939048782955,
          "rotation": 0,
          "target": "3-porte-digue"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-digue_principale",
      "name": "Digue_principale",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": 0.5725780353502508,
        "pitch": 0.43127290399638873,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": -0.22387950721641126,
          "pitch": 0.001517583074324591,
          "rotation": 0,
          "target": "2-milieu-digue"
        },
        {
          "yaw": 0.5377991767570105,
          "pitch": -0.019971621945996887,
          "rotation": 0,
          "target": "0-gare-maritime"
        },
        {
          "yaw": 0.19953409113408327,
          "pitch": -0.037273619233790356,
          "rotation": 0,
          "target": "3-porte-digue"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-milieu-digue",
      "name": "Milieu digue",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": 0.13646947133264398,
        "pitch": 0.21626218566773048,
        "fov": 1.2599180821480807
      },
      "linkHotspots": [
        {
          "yaw": 1.0322280378709898,
          "pitch": -0.01817294060732877,
          "rotation": 0,
          "target": "1-digue_principale"
        },
        {
          "yaw": -0.9538361241436206,
          "pitch": -0.018113648621465472,
          "rotation": 0,
          "target": "3-porte-digue"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-porte-digue",
      "name": "porte digue",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.1823445058200512,
          "pitch": 0.039782013854473774,
          "rotation": 0,
          "target": "4-porte-principale"
        },
        {
          "yaw": -0.07051364991314024,
          "pitch": -0.052452592854617563,
          "rotation": 0,
          "target": "2-milieu-digue"
        },
        {
          "yaw": -0.4666086530912459,
          "pitch": -0.04612057408310477,
          "rotation": 0,
          "target": "1-digue_principale"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-porte-principale",
      "name": "Porte principale",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.0551115090091994,
          "pitch": 0.13860949141485257,
          "rotation": 0,
          "target": "3-porte-digue"
        },
        {
          "yaw": 0.5753974414688354,
          "pitch": 0.1705734664725327,
          "rotation": 0,
          "target": "0-gare-maritime"
        },
        {
          "yaw": 1.0251692999227053,
          "pitch": -0.03163923470193808,
          "rotation": 0,
          "target": "1-digue_principale"
        },
        {
          "yaw": 1.5484010249931206,
          "pitch": -0.016766639603538636,
          "rotation": 0,
          "target": "2-milieu-digue"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Project nador",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
